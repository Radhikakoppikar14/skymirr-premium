import React, { useEffect, useState } from "react";
import { ArrowLeft, ShoppingCart, X, ZoomIn } from "lucide-react";

interface Sky5GDetailPageProps {
  onBack: () => void;
  onContact: () => void;
}

interface LightboxState {
  isOpen: boolean;
  src: string;
  title: string;
}

const IMG = "/images";

/* ---------- Palette (taken from the project's index.css / premium.css) ----------
   navy  #0B1F3A   blue  #1F4FD8   sky  #4C8DF6   ice  #E8F0FE
   muted #5B6B82   line  #E3D4BA   light-cyan #7FD3FF   buy-red #D71920            */

const sideBtn =
  "s5g-shine relative overflow-hidden w-full inline-flex items-center justify-center px-5 py-4 rounded-full bg-gradient-to-r from-[#0B1F3A] to-[#1F4FD8] text-white text-sm font-extrabold text-center border border-[#FF6A00] shadow-none transition-none focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#4C8DF6]/40 cursor-pointer";

const h2 = "s5g-h2 relative text-2xl sm:text-3xl font-extrabold tracking-tight text-[#0B1F3A] font-sans";
const body = "text-base sm:text-lg text-[#475569] leading-[1.8]";
const ul = "s5g-list list-disc pl-5 space-y-2 text-sm text-[#0B1F3A]/90 marker:text-[#1F4FD8]";

const bullets = [
  "42% farther reach to cell towers",
  "Up to 3.4 Gbps download speeds",
  "Twice the coverage area compared to standard solutions",
  "Reliable indoor penetration for homes and businesses",
  "Resilient performance at the network edge and rural sites",
  "Optimized for any environment—rural environments, highways, or bustling cities",
];

const technicalHighlights = [
  "4×4 MIMO 5G",
  "Full FR1 band support (600 MHz–6 GHz)",
  "Wi-Fi 7 (4×4 MU-MIMO)",
  "Supports up to 512 devices",
  "311 ft Wi-Fi radius",
  "2.5 Gbps LAN/WAN",
  "VPN: IPSec, SSL, WireGuard",
  "TR-069 remote management",
  "Dual firmware images & auto-recovery",
  "Optional external SMA antenna ports",
];

const useCases = [
  ["Rural Areas", "Small offices, farms, community centers, schools"],
  ["Professional Offices", "Cloud apps, VoIP & video, multi-device networks"],
  ["Retail & Restaurants", "POS uptime, guest/staff Wi-Fi, digital signage, security cameras"],
  ["Public Safety", "Mobile command, emergency operations, disaster recovery, EOC backup"],
  ["Construction & Field Services", "Portable broadband, trailer connectivity, project uploads, inspections"],
];

/* ---------- Static section wrapper: no scroll or entrance animation ---------- */
type Variant = "up" | "left" | "right" | "zoom";

const Reveal: React.FC<{
  as?: React.ElementType;
  variant?: Variant;
  delay?: number;
  className?: string;
  children: React.ReactNode;
}> = ({ as: Tag = "div", className = "", children }) => (
  <Tag className={className}>{children}</Tag>
);

/* ---------- Scoped styles / keyframes ---------- */
const css = `
.s5g-page .sm-prod-hero-title {
  margin: 0;
  color: #fff;
  font-size: clamp(2.6rem, 5vw, 4.75rem);
  line-height: 1.08;
  font-weight: 800;
  letter-spacing: -0.025em;
  text-shadow: 0 2px 8px rgba(0,0,0,.35);
}
.s5g-page .sm-prod-hero-sub {
  margin-top: .75rem;
  max-width: 72rem;
  color: rgba(255,255,255,.96);
  font-size: clamp(1.15rem, 2.45vw, 2.375rem);
  line-height: 1.25;
  font-weight: 500;
  letter-spacing: .015em;
  text-shadow: 0 2px 6px rgba(0,0,0,.4);
}
@media (max-width: 640px) {
  .s5g-page .sm-prod-hero-title { font-size: clamp(2rem, 9vw, 3rem); }
  .s5g-page .sm-prod-hero-sub { font-size: clamp(1rem, 4vw, 1.35rem); }
}
.s5g-page {
  --orange: #FF6A00;
  --blue: #1F4FD8;
  color: #0B1F3A;
  background: #fff;
}
.s5g-bg { display: none; }
.s5g-hero-img { display: none; }
.s5g-hero-video {
  position: absolute;
  inset: 0;
  z-index: 0;
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  pointer-events: none;
}
.s5g-hero-shade {
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  background: linear-gradient(100deg, rgba(5, 43, 125, .82) 0%, rgba(14, 75, 166, .55) 58%, rgba(255, 106, 0, .24) 100%);
}
.s5g-hero-orange-glow, .s5g-hero-glow, .s5g-waves, .s5g-hero-line { display: none; }
.s5g-orange-accent { color: #FF6A00; }
.s5g-orange-line { background: #FF6A00; }
.s5g-main {
  border-color: rgba(255, 106, 0, .42);
  box-shadow: none !important;
}
.s5g-frame {
  border: 1px solid rgba(255, 106, 0, .65);
  box-shadow: none !important;
  transform: none !important;
  transition: border-color 180ms ease, background-color 180ms ease;
}
.s5g-frame:hover {
  border-color: #1F4FD8;
  box-shadow: none !important;
  transform: none !important;
}
.s5g-shine {
  background: #1F4FD8;
  border: 1px solid #FF6A00;
  box-shadow: none !important;
  transition: background-color 180ms ease, border-color 180ms ease;
}
.s5g-shine:hover {
  background: #1741B8;
  transform: none !important;
  box-shadow: none !important;
}
.s5g-buy {
  background: #0B1F3A;
  border: 1px solid rgba(255, 106, 0, .7);
  box-shadow: none !important;
}
.s5g-pulse, .s5g-float, .s5g-floor, .s5g-zoom-ico { animation: none !important; }
.s5g-logo, .s5g-logo:hover {
  transition: color 180ms ease, border-color 180ms ease;
  transform: none !important;
}
.s5g-floor { display: none !important; }
/* Keep all text stable during scrolling: no scroll-triggered transforms or glitch effects. */
.s5g-word, .s5g-hero-eyebrow, .s5g-hero-sub, .s5g-rv, .s5g-rv-up, .s5g-rv-left, .s5g-rv-right, .s5g-rv-zoom, .s5g-rv.is-in {
  opacity: 1 !important;
  animation: none !important;
  transform: none !important;
  will-change: auto !important;
}
.s5g-h2 { padding-bottom: .65rem; }
.s5g-h2::after {
  content: "";
  display: block;
  position: absolute;
  left: 0;
  bottom: 0;
  width: 54px;
  height: 3px;
  border-radius: 3px;
  background: #FF6A00;
  transform: none !important;
  transition: none !important;
}
.s5g-list li {
  opacity: 1 !important;
  transform: none !important;
  transition: none !important;
}
.s5g-list li:hover { color: inherit; }
.s5g-shine::after, .s5g-shine:hover::after { display: none !important; animation: none !important; }
.s5g-fade, .s5g-pop { animation: none !important; }

/* Balanced SkyMirr palette: blue is primary, orange is the accent */
.s5g-info-card {
  border-color: #D8E2F3;
  border-top-color: #1F4FD8;
}
.s5g-info-card:nth-child(even) {
  border-top-color: #FF6A00;
}
.s5g-product-showcase {
  border-color: #1F4FD8;
}
.s5g-product-showcase::after {
  content: "";
  position: absolute;
  inset: auto 0 0;
  height: 4px;
  background: linear-gradient(90deg, #1F4FD8 0%, #1F4FD8 68%, #FF6A00 68%, #FF6A00 100%);
}
.s5g-marketplace {
  display: inline-flex;
  width: 100%;
  min-height: 52px;
  align-items: center;
  justify-content: center;
  gap: 5px;
  border: 1px solid #DCE3ED;
  border-radius: 10px;
  background: #FFFFFF;
  padding: 7px 12px;
  color: #0B1F3A;
  text-decoration: none;
  box-shadow: none !important;
  transition: none !important;
}
.s5g-marketplace:hover {
  border-color: #FF6A00;
  transform: none !important;
  box-shadow: none !important;
}
.s5g-marketplace-amazon { color: #111827; }

.s5g-marketplace-walmart { color: #0071CE; }
.s5g-marketplace-digikey { color: #CC0000; }
.s5g-marketplace-bh { color: #D71920; }
.s5g-info-card {
  min-width: 0;
  border: 1px solid #E2E8F0;
  border-top: 3px solid #1F4FD8;
  border-radius: 1.5rem;
  background: #FFFFFF;
  padding: 1.5rem;
  box-shadow: none !important;
}
@media (min-width: 640px) {
  .s5g-info-card { padding: 2rem; }
}
.s5g-page .s5g-h2 { color: #0B1F3A !important; }
.s5g-page .s5g-list,
.s5g-page .s5g-list li { color: #475569 !important; }
.s5g-page .s5g-list strong,
.s5g-page .s5g-list b { color: #334155 !important; }
.s5g-page .s5g-list li::marker { color: #FF6A00; }
.s5g-product-showcase {
  box-shadow: none !important;
  transform: none !important;
  transition: none !important;
}
.s5g-product-showcase:hover {
  box-shadow: none !important;
  transform: none !important;
  border-color: #FF6A00;
}
.s5g-product-showcase img {
  transform: none !important;
  transition: none !important;
  filter: none !important;
}

@keyframes s5g-section-enter {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
.s5g-page .s5g-info-card {
  animation: none !important;
  transition: border-color 180ms ease, background-color 180ms ease;
}
.s5g-page .s5g-info-card:hover { border-color: #9DB5F7; }
.s5g-page button:not(.s5g-product-showcase) { transition: background-color 180ms ease, border-color 180ms ease; }
.s5g-page img, .s5g-page svg[role="img"] { transform: none !important; transition: none !important; }
@media (prefers-reduced-motion: reduce) {
  .s5g-page .s5g-info-card { animation: none !important; transition: none !important; }
  .s5g-page button { transition: none !important; }
}
@media (max-width: 767px) {
  .sky5g-hero { min-height: 300px; }
  .sky5g-content { padding-top: 1.5rem; }
}
@media (prefers-reduced-motion: reduce) {
  .s5g-page *, .s5g-page *::before, .s5g-page *::after {
    animation: none !important;
    transition: none !important;
    scroll-behavior: auto !important;
  }
}
`;

const heroTitle = "Sky5G Wireless Router";

export const Sky5GDetailPage: React.FC<Sky5GDetailPageProps> = ({ onBack, onContact }) => {
  const [lightbox, setLightbox] = useState<LightboxState>({ isOpen: false, src: "", title: "" });
  const open = (src: string, title: string) => setLightbox({ isOpen: true, src, title });
  const close = () => setLightbox((p) => ({ ...p, isOpen: false }));

  useEffect(() => {
    if (!lightbox.isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox.isOpen]);

  return (
    <div className="s5g-page pdx-page relative isolate pt-[72px] pb-24 bg-white text-[#0B1F3A]">
      <style>{css}</style>

      {/* Breadcrumb */}
      <div className="bg-white border-b border-[#FF6A00]/40 py-4 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button
            onClick={onBack}
            className="group inline-flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-[#5B6B82] hover:text-[#1F4FD8] cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 " />
            <span>Back to Products</span>
          </button>
          <div className="flex items-center gap-2 text-xs font-mono text-[#5B6B82]">
            <span>CPEs</span>
            <span>/</span>
            <span className="text-[#1F4FD8] font-bold bg-[#E8F0FE] px-3 py-0.5 rounded-full tracking-wider">
              TCPA 117 (Sky5G® Router)
            </span>
          </div>
        </div>
      </div>

      {/* Sky5G hero: matches the Antennas banner dimensions, typography, and background video */}
      <section className="sm-prod-hero sky5g-hero relative isolate flex min-h-[260px] items-center overflow-hidden border-b-4 border-[#FF6A00] bg-[#0B1F3A] text-white sm:min-h-[360px] mb-8">
        <video
          className="s5g-hero-video absolute inset-0 z-0 h-full w-full object-cover object-center"
          autoPlay
          loop
          muted
          playsInline
          preload="metadata"
          poster="/images/slider2-1536x550.jpg"
          aria-hidden="true"
        >
          <source src="/assets/slider-background.mp4" type="video/mp4" />
        </video>
        <div
          aria-hidden="true"
          className="absolute inset-0 z-[1] pointer-events-none"
          style={{
            background:
              "linear-gradient(100deg, rgba(5,43,125,.82) 0%, rgba(14,75,166,.55) 58%, rgba(255,106,0,.24) 100%)",
          }}
        />
        <div className="relative z-[2] mx-auto w-full max-w-7xl px-5 py-16 sm:px-6 sm:py-20 lg:px-8">
          <h1 className="sm-prod-hero-title">Sky5G Wireless Router</h1>
          <p className="sm-prod-hero-sub">Unleashing Reliable Connectivity Anywhere</p>
        </div>
      </section>

      {/* Redesigned product overview */}
      <div className="mx-auto max-w-[1440px] px-4 py-7 sm:px-6 sm:py-9 lg:px-10">
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-7">
            <button
              type="button"
              onClick={() => open(`${IMG}/Sky5G_TCPA117_CES_awards_original_crop.png`, "Sky5G TCPA 117")}
              aria-label="Open larger Sky5G TCPA 117 product image"
              className="s5g-product-showcase relative flex min-h-[300px] w-full items-center justify-center overflow-hidden rounded-[1.75rem] border border-[#FF6A00]/70 bg-white p-5 sm:min-h-[430px] sm:p-10"
            >
              <span aria-hidden="true" className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-[#1F4FD8] via-[#1F4FD8] to-[#FF6A00]" />
              <span className="absolute left-5 top-5 inline-flex items-center rounded-full border border-[#FF6A00]/50 bg-[#FFF4EC] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#B94B00]">
                Sky5G Router
              </span>
              <span className="absolute right-5 top-5 inline-flex items-center justify-center rounded-full border border-[#FF6A00]/50 bg-white p-2 text-[#1F4FD8]">
                <ZoomIn className="h-4 w-4" />
              </span>
              <img
                src={`${IMG}/Sky5G_TCPA117_CES_awards_original_crop.png`}
                alt="Sky5G TCPA 117 Router"
                loading="eager"
                decoding="async"
                fetchPriority="high"
                className="relative z-[1] block h-auto max-h-[470px] w-full max-w-[700px] object-contain"
              />
            </button>
            <p className="mt-3 text-xs text-[#64748B]">Select the image to view it larger.</p>
          </div>

          <div className="flex flex-col gap-5 lg:col-span-5">
            <div className="flex flex-1 flex-col justify-center rounded-[1.75rem] border border-[#E1E7F0] bg-[#F7F9FC] p-6 sm:p-8">
              <span className="mb-4 inline-flex w-fit items-center rounded-full bg-[#EAF0FF] px-3 py-1.5 text-xs font-bold uppercase tracking-[0.14em] text-[#1F4FD8]">
                SkyMirr · 5G Connectivity
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight text-[#0B1F3A] sm:text-4xl">Sky5G TCPA 117</h2>
              <div className="mt-4 h-1 w-16 rounded-full bg-[#FF6A00]" />
              <p className="mt-5 text-base font-semibold leading-relaxed text-[#334155] sm:text-lg">
                5G Sub-6 /4G LTE Wireless Customer Premises Equipment/Router
              </p>
              <div className="mt-6 border-t border-[#DCE3ED] pt-5">
                <p className="text-sm font-semibold text-[#64748B]">For detailed performance specifications and product datasheet, contact SkyMirr at</p>
                <a href="mailto:sales@skymirr.com" className="mt-2 inline-block font-bold text-[#1F4FD8] underline-offset-4 hover:underline">
                  sales@skymirr.com
                </a>
                .
              </div>
            </div>

            <div className="rounded-[1.5rem] border border-[#FF6A00]/60 bg-white p-4 sm:p-5">
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                <button type="button" className={`${sideBtn} !px-3 !py-3 !text-xs`}>Download Latest Firmware</button>
                <button type="button" className={`${sideBtn} !px-3 !py-3 !text-xs`}>Quickstart Guide</button>
                <button type="button" className={`${sideBtn} !px-3 !py-3 !text-xs`}>Customer FAQs</button>
              </div>
              <div className="mt-4 border-t border-[#E6EAF0] pt-4">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-[#64748B]">Available from</p>
                    <p className="mt-1 text-xl font-extrabold text-[#0B1F3A]">B&amp;H Photo Video</p>
                    <p className="mt-1 text-sm text-[#64748B]">an authorized SkyMirr reseller.</p>
                  </div>
                  <a
                    href="https://www.bhphotovideo.com/c/search?q=skymirr"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex shrink-0 items-center justify-center rounded-full border border-[#FF6A00] bg-[#1F4FD8] px-5 py-3 text-sm font-bold text-white"
                  >
                    Shop at B&amp;H →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Product information — same copy, reorganized into a cleaner editorial grid */}
        <div className="mt-10 grid grid-cols-1 gap-5 md:grid-cols-2 lg:mt-14 lg:gap-6">
          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">01 / The problem</p>
            <h2 className={h2}>The Challenge</h2>
            <p className={body}>
              In rugged landscapes and dense urban environments, millions struggle with slow, unstable internet. Weak
              RF signals and limited fiber access create persistent connectivity gaps, restricting education,
              commerce, and everyday life.
            </p>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">02 / The solution</p>
            <h2 className={h2}>The Solution: SkyMirr Sky5G Router</h2>
            <p className={body}>
              Meet the SkyMirr Sky5G Router—engineered for businesses, communities, and users who demand fast,
              resilient, and secure broadband. Fully certified on T-Mobile’s 5G network and T-Priority, Sky5G sets a
              new standard for performance, even in locations where other routers can’t deliver.
            </p>
            <p className={body}>
              Sky5G is a <strong className="text-[#0B1F3A]">CES2026 Innovation Award Honoree</strong>.
            </p>
          </section>

          <section className="md:col-span-2 grid grid-cols-1 items-start gap-6 lg:grid-cols-12 lg:gap-8">
            <aside className="s5g-info-card space-y-4 lg:col-span-4">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#64748B]">Buy Online</p>
              <div className="grid grid-cols-2 gap-3">
                <a href="https://www.amazon.com/s?k=skymirr" target="_blank" rel="noreferrer" aria-label="Search SkyMirr on Amazon" className="s5g-marketplace s5g-marketplace-amazon">
                  <svg viewBox="0 0 96 34" role="img" aria-label="Amazon" className="h-7 w-[76px]" fill="none"><text x="8" y="22" fontSize="23" fontWeight="700" fill="#172033" fontFamily="Arial, sans-serif">amazon</text><path d="M20 27 C37 34 61 33 77 25" stroke="#FF9900" strokeWidth="2.8" strokeLinecap="round"/><path d="M70 24 L78 24 L75 30" stroke="#FF9900" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </a>
                <a href="https://www.walmart.com/search?q=skymirr" target="_blank" rel="noreferrer" aria-label="Search SkyMirr on Walmart" className="s5g-marketplace s5g-marketplace-walmart">
                  <svg viewBox="0 0 112 28" role="img" aria-label="Walmart" className="h-6 w-[92px]"><text x="0" y="20" fontSize="19" fontWeight="700" fill="#0071CE" fontFamily="Arial, sans-serif">Walmart</text><g transform="translate(96 13)" fill="#FFC220"><rect x="-1.5" y="-7" width="3" height="6" rx="1.5"/><rect x="-1.5" y="1" width="3" height="6" rx="1.5"/><rect x="-7" y="-1.5" width="6" height="3" rx="1.5"/><rect x="1" y="-1.5" width="6" height="3" rx="1.5"/><rect x="-5.7" y="-5.7" width="3" height="6" rx="1.5" transform="rotate(-45 -4.2 -2.7)"/><rect x="2.7" y="1.7" width="3" height="6" rx="1.5" transform="rotate(-45 4.2 4.7)"/></g></svg>
                </a>
                <a href="https://www.digikey.com/en/supplier-centers/skymirr" target="_blank" rel="noreferrer" aria-label="Find SkyMirr on DigiKey" className="s5g-marketplace s5g-marketplace-digikey"><svg viewBox="0 0 96 28" role="img" aria-label="DigiKey" className="h-6 w-[78px]"><text x="0" y="20" fontSize="20" fontWeight="800" fill="#CC0000" fontFamily="Arial, sans-serif">DigiKey</text></svg></a>
                <a href="https://www.bhphotovideo.com/c/search?q=skymirr" target="_blank" rel="noreferrer" aria-label="Search SkyMirr at B&H" className="s5g-marketplace s5g-marketplace-bh"><svg viewBox="0 0 54 28" role="img" aria-label="B&H Photo Video" className="h-6 w-[48px]"><text x="0" y="21" fontSize="21" fontWeight="900" fill="#D71920" fontFamily="Arial, sans-serif">B&amp;H</text></svg></a>
              </div>
              <button type="button" onClick={onContact} className={`${sideBtn} !py-3`}>Contact Skymirr For Bulk Purchase (MOQ: 10 Units)</button>
              <div className="rounded-xl border border-[#D8E2F3] bg-[#F5F8FF] p-3 text-sm text-[#475569]">
                <span className="font-bold text-[#1F4FD8]">Need a bulk order?</span> Contact SkyMirr for purchasing support and availability.
              </div>
            </aside>
            <div className="s5g-info-card space-y-4 lg:col-span-8">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">03 / Product engineering</p>
            <h2 className={h2}>Superior Connectivity By Design</h2>
            <p className={body}>
              Unlike traditional routers where antennas are an afterthought, SkyMirr’s exclusive MuLCAT®
              antenna-first engineering puts signal strength and reliability front and center. Experience up to{" "}
              <strong className="text-[#0B1F3A]">42% farther reach to cell towers</strong>, enhanced indoor coverage,
              and consistently high speeds—even during network congestion or in remote locations.
            </p>
            <div
              role="img"
              aria-label="Illustration of a Sky5G router communicating wirelessly with a cellular base station and connected devices"
              className="s5g-frame w-full overflow-hidden rounded-2xl bg-[#F5F8FF] p-3 sm:p-5"
            >
              <svg viewBox="0 0 1000 330" className="block h-auto w-full" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="sky5g-diagram-title">
                <title id="sky5g-diagram-title">Local Wi-Fi 7 Sky5G wireless link to a 5G base station</title>
                <defs>
                  <linearGradient id="sky5gRouterFill" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#315FE3"/><stop offset="100%" stopColor="#0B1F3A"/></linearGradient>
                  <marker id="sky5gArrowBlue" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" fill="#1F4FD8"/></marker>
                </defs>
                <rect x="1" y="1" width="998" height="328" rx="18" fill="#FFFFFF" stroke="#D8E2F3" strokeWidth="2"/>
                {/* Local connected devices */}
                <g stroke="#334155" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none">
                  <g transform="translate(55 34)"><rect x="0" y="0" width="40" height="28" rx="2"/><path d="M-4 34 H44 M8 28 L4 34 M32 28 L36 34"/><path d="M6 8 H34 M6 14 H27"/></g>
                  <g transform="translate(170 24)"><rect x="0" y="0" width="38" height="31" rx="2"/><path d="M-4 37 H42 M8 31 L5 37 M30 31 L33 37"/><path d="M7 8 H31 M7 15 H31 M7 22 H25"/></g>
                  <g transform="translate(53 117)"><rect x="0" y="0" width="25" height="43" rx="2"/><rect x="30" y="12" width="15" height="25" rx="2"/><circle cx="12" cy="35" r="1.8"/></g>
                  <g transform="translate(170 112)"><rect x="0" y="0" width="42" height="26" rx="2"/><path d="M21 26 V34 M8 35 H34"/></g>
                  <g transform="translate(52 205)"><path d="M0 25 L10 0 H42 L52 25 Z"/><path d="M6 25 H47 M26 25 V31 M16 31 H37"/></g>
                  <g transform="translate(175 204)"><rect x="0" y="0" width="34" height="48" rx="2"/><path d="M8 8 H26 M8 15 H26 M8 22 H26"/></g>
                  <g transform="translate(115 267)"><rect x="0" y="0" width="44" height="30" rx="2"/><path d="M-5 35 H49 M8 30 L4 35 M36 30 L40 35"/></g>
                </g>
                {/* Router at the center */}
                <g transform="translate(375 93)">
                  <rect x="0" y="0" width="130" height="112" rx="14" fill="#F5F8FF" stroke="#1F4FD8" strokeWidth="3"/>
                  <rect x="18" y="20" width="94" height="70" rx="8" fill="url(#sky5gRouterFill)"/>
                  <path d="M34 43 Q65 10 96 43 M43 52 Q65 31 87 52 M54 61 Q65 51 76 61" fill="none" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round"/>
                  <circle cx="65" cy="75" r="4" fill="#FF8A35"/>
                  <path d="M18 100 H112" stroke="#FF6A00" strokeWidth="4" strokeLinecap="round"/>
                </g>
                <text x="440" y="228" textAnchor="middle" fill="#1F4FD8" fontSize="18" fontWeight="700" fontFamily="Arial, sans-serif">Sky5G</text>
                <text x="440" y="249" textAnchor="middle" fill="#64748B" fontSize="14" fontWeight="600" fontFamily="Arial, sans-serif">LOCAL WiFi7</text>
                {/* Device links around the router */}
                <g stroke="#1F4FD8" strokeWidth="2.5" fill="none" markerEnd="url(#sky5gArrowBlue)">
                  <path d="M215 51 L358 111"/><path d="M215 130 L356 139"/><path d="M215 222 L359 183"/><path d="M157 267 L385 206"/>
                  <path d="M505 140 C585 140 610 140 695 140"/>
                </g>
                <text x="600" y="120" textAnchor="middle" fill="#334155" fontSize="15" fontWeight="700" fontFamily="Arial, sans-serif">5G Sub6 / 4G LTE</text>
                <text x="600" y="162" textAnchor="middle" fill="#334155" fontSize="15" fontWeight="700" fontFamily="Arial, sans-serif">Wireless Link</text>
                {/* Cellular tower */}
                <g transform="translate(760 38)" stroke="#FF6A00" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none">
                  <path d="M60 62 L15 240 M60 62 L105 240 M28 187 H92 M36 155 H84 M44 122 H76 M52 91 H68"/>
                  <path d="M60 62 V30"/><path d="M42 36 Q60 15 78 36 M29 24 Q60 -8 91 24"/>
                  <path d="M45 80 H75 M39 111 H81"/>
                </g>
                <text x="820" y="300" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="700" fontFamily="Arial, sans-serif">BASE STATION</text>
                <text x="110" y="315" textAnchor="middle" fill="#64748B" fontSize="13" fontWeight="600" fontFamily="Arial, sans-serif">Connected devices</text>
              </svg>
            </div>
            <ul className={ul}>
              {bullets.map((b) => <li key={b}>{b}</li>)}
            </ul>
            </div>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">04 / Core technology</p>
            <h2 className={h2}>Superior Connectivity By Design</h2>
            <ul className={ul}>
              <li>
                <strong>MuLCAT® Antenna:</strong> AI-driven, real-time optimization ensures peak performance and
                extends connectivity to challenging areas without upgrading carrier networks.
              </li>
              <li>
                <strong>Wi-Fi 7 Integration:</strong> Delivers seamless, high-speed connections for streaming, remote
                work, and online learning.
              </li>
            </ul>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">05 / Benefits</p>
            <h2 className={h2}>Key Benefits</h2>
            <ul className={ul}>
              <li><strong>2x Coverage Area:</strong> Connect more users and devices across broader spaces.</li>
              <li><strong>50% Power Savings:</strong> Lower energy consumption for cost-effective, sustainable operations.</li>
              <li><strong>Real-Time Optimization:</strong> Automatic adjustments keep your connection strong in tough conditions.</li>
            </ul>
          </section>

          <section className="s5g-info-card space-y-4 md:col-span-2">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">06 / Network compatibility</p>
            <p className={body}>Sky5G is certified for</p>
            <ul className={ul}>
              <li>
                <strong>T-Mobile’s Standard 5G Network</strong>—delivering fast speeds, broad coverage, and
                enterprise-grade reliability.
              </li>
              <li>
                <strong>T-Priority</strong>- where mission-critical users enjoy elevated network access, priority
                queuing during congestion, hardened connections for public safety, and enhanced reliability for first
                responders and emergency services. It is approved for use by: Police, Fire, EMS, emergency operations,
                public works, school districts, utility and infrastructure agencies.
              </li>
              <li>
                <strong>AT&amp;T’s standard 5G network</strong> - delivering reliable 5G connectivity on the AT&amp;T
                network for business, mobile, and connectivity-challenged environments.
              </li>
            </ul>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">07 / Specifications</p>
            <h2 className={h2}>Technical Highlights</h2>
            <ul className={`${ul} s5g-cols`}>
              {technicalHighlights.map((t) => <li key={t}>{t}</li>)}
            </ul>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">08 / Applications</p>
            <h2 className={h2}>Versatile Use Cases</h2>
            <ul className={ul}>
              {useCases.map(([t, d]) => (
                <li key={t}><strong>{t}:</strong> {d}</li>
              ))}
            </ul>
          </section>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox.isOpen && (
        <div
          onClick={close}
          className="s5g-fade fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-[#0B1F3A]/85 cursor-zoom-out"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="s5g-pop relative bg-white rounded-3xl max-w-6xl w-full max-h-[92vh] overflow-auto p-6 sm:p-8 border border-[#4C8DF6]"
          >
            <div className="flex items-center justify-between pb-4 border-b border-[#E3D4BA]">
              <h3 className="text-sm sm:text-base font-bold text-[#0B1F3A]">{lightbox.title}</h3>
              <button
                onClick={close}
                aria-label="Close"
                className="p-2 rounded-xl text-[#5B6B82] hover:bg-[#E8F0FE] hover:text-[#1F4FD8] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="pt-6 flex justify-center">
              <img src={lightbox.src} alt={lightbox.title} className="max-w-full h-auto object-contain" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};