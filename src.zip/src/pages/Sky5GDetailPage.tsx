import React, { useEffect, useState } from "react";
import { ArrowLeft, ShoppingCart, X, ZoomIn } from "lucide-react";

interface Sky5GDetailPageProps {
  onBack: () => void;
  onContact: () => void;
}

interface LightboxState {
  isOpen: boolean;
  src: string;
  title: string;
}

const IMG = "/images";

/* ---------- Palette (taken from the project's index.css / premium.css) ----------
   navy  #0B1F3A   blue  #1F4FD8   sky  #4C8DF6   ice  #E8F0FE
   muted #5B6B82   line  #E3D4BA   light-cyan #7FD3FF   buy-red #D71920            */

const sideBtn =
  "s5g-shine relative overflow-hidden w-full inline-flex items-center justify-center px-5 py-4 rounded-full bg-gradient-to-r from-[#0B1F3A] to-[#1F4FD8] text-white text-sm font-extrabold text-center border border-[#FF6A00] shadow-none transition-none focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#4C8DF6]/40 cursor-pointer";

const h2 = "s5g-h2 relative text-2xl sm:text-3xl font-extrabold tracking-tight text-[#0B1F3A] font-sans";
const body = "text-base sm:text-lg text-[#475569] leading-[1.8]";
const ul = "s5g-list list-disc pl-5 space-y-2 text-sm text-[#0B1F3A]/90 marker:text-[#1F4FD8]";

const bullets = [
  "42% farther reach to cell towers",
  "Up to 3.4 Gbps download speeds",
  "Twice the coverage area compared to standard solutions",
  "Reliable indoor penetration for homes and businesses",
  "Resilient performance at the network edge and rural sites",
  "Optimized for any environment—rural environments, highways, or bustling cities",
];

const technicalHighlights = [
  "4×4 MIMO 5G",
  "Full FR1 band support (600 MHz–6 GHz)",
  "Wi-Fi 7 (4×4 MU-MIMO)",
  "Supports up to 512 devices",
  "311 ft Wi-Fi radius",
  "2.5 Gbps LAN/WAN",
  "VPN: IPSec, SSL, WireGuard",
  "TR-069 remote management",
  "Dual firmware images & auto-recovery",
  "Optional external SMA antenna ports",
];

const useCases = [
  ["Rural Areas", "Small offices, farms, community centers, schools"],
  ["Professional Offices", "Cloud apps, VoIP & video, multi-device networks"],
  ["Retail & Restaurants", "POS uptime, guest/staff Wi-Fi, digital signage, security cameras"],
  ["Public Safety", "Mobile command, emergency operations, disaster recovery, EOC backup"],
  ["Construction & Field Services", "Portable broadband, trailer connectivity, project uploads, inspections"],
];

/* ---------- Static section wrapper: no scroll or entrance animation ---------- */
type Variant = "up" | "left" | "right" | "zoom";

const Reveal: React.FC<{
  as?: React.ElementType;
  variant?: Variant;
  delay?: number;
  className?: string;
  children: React.ReactNode;
}> = ({ as: Tag = "div", className = "", children }) => (
  <Tag className={className}>{children}</Tag>
);

/* ---------- Scoped styles / keyframes ---------- */
const css = `
.s5g-page {
  --orange: #FF6A00;
  --blue: #1F4FD8;
  color: #0B1F3A;
  background: #fff;
}
.s5g-bg { display: none; }
.s5g-hero-img { display: none; }
.s5g-hero-video {
  position: absolute;
  inset: 0;
  z-index: -2;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
}
.s5g-hero-shade {
  position: absolute;
  inset: 0;
  z-index: -1;
  background: linear-gradient(100deg, rgba(7, 35, 102, .88) 0%, rgba(15, 67, 150, .68) 58%, rgba(31, 79, 216, .24) 100%);
}
.s5g-hero-orange-glow, .s5g-hero-glow, .s5g-waves, .s5g-hero-line { display: none; }
.s5g-orange-accent { color: #FF6A00; }
.s5g-orange-line { background: #FF6A00; }
.s5g-main {
  border-color: rgba(255, 106, 0, .42);
  box-shadow: none !important;
}
.s5g-frame {
  border: 1px solid rgba(255, 106, 0, .65);
  box-shadow: none !important;
  transform: none !important;
  transition: none !important;
}
.s5g-frame:hover {
  border-color: #FF6A00;
  box-shadow: none !important;
  transform: none !important;
}
.s5g-shine {
  background: #1F4FD8;
  border: 1px solid #FF6A00;
  box-shadow: none !important;
  transition: none !important;
}
.s5g-shine:hover {
  background: #1F4FD8;
  transform: none !important;
  box-shadow: none !important;
}
.s5g-buy {
  background: #0B1F3A;
  border: 1px solid rgba(255, 106, 0, .7);
  animation: none !important;
  box-shadow: none !important;
}
.s5g-pulse { animation: none !important; }
.s5g-logo, .s5g-logo:hover {
  transition: none !important;
  transform: none !important;
}
.s5g-float, .s5g-floor, .s5g-zoom-ico { animation: none !important; }
.s5g-floor { display: none !important; }
.s5g-word, .s5g-hero-eyebrow, .s5g-hero-sub {
  opacity: 1 !important;
  animation: none !important;
}
.s5g-rv, .s5g-rv-up, .s5g-rv-left, .s5g-rv-right, .s5g-rv-zoom, .s5g-rv.is-in {
  opacity: 1 !important;
  transform: none !important;
  transition: none !important;
  will-change: auto !important;
}
.s5g-h2 { padding-bottom: .65rem; }
.s5g-h2::after {
  content: "";
  display: block;
  position: absolute;
  left: 0;
  bottom: 0;
  width: 54px;
  height: 3px;
  border-radius: 3px;
  background: #FF6A00;
  transform: none !important;
  transition: none !important;
}
.s5g-list li {
  opacity: 1 !important;
  transform: none !important;
  transition: none !important;
}
.s5g-list li:hover { color: inherit; }
.s5g-shine::after, .s5g-shine:hover::after { display: none !important; animation: none !important; }
.s5g-fade, .s5g-pop { animation: none !important; }

/* Balanced SkyMirr palette: blue is primary, orange is the accent */
.s5g-info-card {
  border-color: #D8E2F3;
  border-top-color: #1F4FD8;
}
.s5g-info-card:nth-child(even) {
  border-top-color: #FF6A00;
}
.s5g-product-showcase {
  border-color: #1F4FD8;
}
.s5g-product-showcase::after {
  content: "";
  position: absolute;
  inset: auto 0 0;
  height: 4px;
  background: linear-gradient(90deg, #1F4FD8 0%, #1F4FD8 68%, #FF6A00 68%, #FF6A00 100%);
}
.s5g-marketplace {
  display: inline-flex;
  min-height: 42px;
  align-items: center;
  justify-content: center;
  gap: 5px;
  border: 1px solid #DCE3ED;
  border-radius: 10px;
  background: #FFFFFF;
  padding: 7px 12px;
  color: #0B1F3A;
  text-decoration: none;
  box-shadow: none !important;
  transition: none !important;
}
.s5g-marketplace:hover {
  border-color: #FF6A00;
  transform: none !important;
  box-shadow: none !important;
}
.s5g-marketplace-amazon { color: #111827; }

.s5g-marketplace-walmart { color: #0071CE; }
.s5g-marketplace-digikey { color: #CC0000; }
.s5g-marketplace-bh { color: #D71920; }
.s5g-info-card {
  min-width: 0;
  border: 1px solid #E2E8F0;
  border-top: 3px solid #FF6A00;
  border-radius: 1.5rem;
  background: #FFFFFF;
  padding: 1.5rem;
  box-shadow: none !important;
}
@media (min-width: 640px) {
  .s5g-info-card { padding: 2rem; }
}
.s5g-page .s5g-h2 { color: #0B1F3A !important; }
.s5g-page .s5g-list,
.s5g-page .s5g-list li { color: #475569 !important; }
.s5g-page .s5g-list strong,
.s5g-page .s5g-list b { color: #334155 !important; }
.s5g-page .s5g-list li::marker { color: #FF6A00; }
.s5g-product-showcase {
  box-shadow: none !important;
  transform: none !important;
  transition: none !important;
}
.s5g-product-showcase:hover {
  box-shadow: none !important;
  transform: none !important;
  border-color: #FF6A00;
}
.s5g-product-showcase img {
  transform: none !important;
  transition: none !important;
  filter: none !important;
}
@media (max-width: 767px) {
  .sky5g-hero { min-height: 300px; }
  .sky5g-content { padding-top: 1.5rem; }
}
@media (prefers-reduced-motion: reduce) {
  .s5g-page *, .s5g-page *::before, .s5g-page *::after {
    animation: none !important;
    transition: none !important;
    scroll-behavior: auto !important;
  }
}
`;

const heroTitle = "Sky5G Wireless Router";

export const Sky5GDetailPage: React.FC<Sky5GDetailPageProps> = ({ onBack, onContact }) => {
  const [lightbox, setLightbox] = useState<LightboxState>({ isOpen: false, src: "", title: "" });
  const open = (src: string, title: string) => setLightbox({ isOpen: true, src, title });
  const close = () => setLightbox((p) => ({ ...p, isOpen: false }));

  useEffect(() => {
    if (!lightbox.isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox.isOpen]);

  return (
    <div className="s5g-page pdx-page relative isolate pt-[72px] pb-24 bg-white text-[#0B1F3A]">
      <style>{css}</style>

      {/* Breadcrumb */}
      <div className="bg-white border-b border-[#FF6A00]/40 py-4 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button
            onClick={onBack}
            className="group inline-flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-[#5B6B82] hover:text-[#1F4FD8] cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 " />
            <span>Back to Products</span>
          </button>
          <div className="flex items-center gap-2 text-xs font-mono text-[#5B6B82]">
            <span>CPEs</span>
            <span>/</span>
            <span className="text-[#1F4FD8] font-bold bg-[#E8F0FE] px-3 py-0.5 rounded-full tracking-wider">
              TCPA 117 (Sky5G® Router)
            </span>
          </div>
        </div>
      </div>

      {/* Image-led hero banner. Place a high-resolution hero image at
          public/images/sky5g-hero-bg.jpg (1600px wide or larger recommended). */}
      <section className="sky5g-hero relative isolate flex min-h-[300px] sm:min-h-[450px] items-center overflow-hidden border-b-4 border-[#FF6A00] bg-[#0B1F3A] text-white">
        <video
          className="s5g-hero-video"
          autoPlay
          loop
          muted
          playsInline
          preload="metadata"
          poster="/images/slider2-1536x550.jpg"
          aria-hidden="true"
        >
          <source src="/assets/slider-background.mp4" type="video/mp4" />
        </video>
        <div aria-hidden="true" className="s5g-hero-shade" />
        <div className="mx-auto w-full max-w-7xl px-5 py-16 sm:px-8 sm:py-24 lg:px-10">
          <h1 className="max-w-5xl text-4xl font-extrabold leading-tight tracking-wide text-white drop-shadow-[0_2px_8px_rgba(0,0,0,.55)] sm:text-5xl lg:text-[76px]">
            {heroTitle}
          </h1>
          <p className="s5g-hero-sub mt-3 max-w-6xl text-lg font-medium leading-snug tracking-wide text-white/95 drop-shadow-[0_2px_6px_rgba(0,0,0,.65)] sm:text-2xl lg:text-[38px]">
            Unleashing Reliable Connectivity Anywhere
          </p>
        </div>
      </section>

      {/* Redesigned product overview */}
      <div className="mx-auto max-w-[1440px] px-4 py-8 sm:px-6 sm:py-12 lg:px-10">
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-7">
            <button
              type="button"
              onClick={() => open(`${IMG}/Sky5G_TCPA117_CES_awards_original_crop.png`, "Sky5G TCPA 117")}
              aria-label="Open larger Sky5G TCPA 117 product image"
              className="s5g-product-showcase relative flex min-h-[300px] w-full items-center justify-center overflow-hidden rounded-[1.75rem] border border-[#FF6A00]/70 bg-white p-5 sm:min-h-[430px] sm:p-10"
            >
              <span aria-hidden="true" className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-[#1F4FD8] via-[#1F4FD8] to-[#FF6A00]" />
              <span className="absolute left-5 top-5 inline-flex items-center rounded-full border border-[#FF6A00]/50 bg-[#FFF4EC] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#B94B00]">
                Sky5G Router
              </span>
              <span className="absolute right-5 top-5 inline-flex items-center justify-center rounded-full border border-[#FF6A00]/50 bg-white p-2 text-[#1F4FD8]">
                <ZoomIn className="h-4 w-4" />
              </span>
              <img
                src={`${IMG}/Sky5G_TCPA117_CES_awards_original_crop.png`}
                alt="Sky5G TCPA 117 Router"
                loading="eager"
                decoding="async"
                fetchPriority="high"
                className="relative z-[1] block h-auto max-h-[470px] w-full max-w-[700px] object-contain"
              />
            </button>
            <p className="mt-3 text-xs text-[#64748B]">Select the image to view it larger.</p>
          </div>

          <div className="flex flex-col gap-5 lg:col-span-5">
            <div className="flex flex-1 flex-col justify-center rounded-[1.75rem] border border-[#E1E7F0] bg-[#F7F9FC] p-6 sm:p-8">
              <span className="mb-4 inline-flex w-fit items-center rounded-full bg-[#EAF0FF] px-3 py-1.5 text-xs font-bold uppercase tracking-[0.14em] text-[#1F4FD8]">
                SkyMirr · 5G Connectivity
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight text-[#0B1F3A] sm:text-4xl">Sky5G TCPA 117</h2>
              <div className="mt-4 h-1 w-16 rounded-full bg-[#FF6A00]" />
              <p className="mt-5 text-base font-semibold leading-relaxed text-[#334155] sm:text-lg">
                5G Sub-6 /4G LTE Wireless Customer Premises Equipment/Router
              </p>
              <div className="mt-6 border-t border-[#DCE3ED] pt-5">
                <p className="text-sm font-semibold text-[#64748B]">For detailed performance specifications and product datasheet, contact SkyMirr at</p>
                <a href="mailto:sales@skymirr.com" className="mt-2 inline-block font-bold text-[#1F4FD8] underline-offset-4 hover:underline">
                  sales@skymirr.com
                </a>
                .
              </div>
            </div>

            <div className="rounded-[1.5rem] border border-[#FF6A00]/60 bg-white p-4 sm:p-5">
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                <button type="button" className={`${sideBtn} !px-3 !py-3 !text-xs`}>Download Latest Firmware</button>
                <button type="button" className={`${sideBtn} !px-3 !py-3 !text-xs`}>Quickstart Guide</button>
                <button type="button" className={`${sideBtn} !px-3 !py-3 !text-xs`}>Customer FAQs</button>
              </div>
              <div className="mt-4 border-t border-[#E6EAF0] pt-4">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-[#64748B]">Available from</p>
                    <p className="mt-1 text-xl font-extrabold text-[#0B1F3A]">B&amp;H Photo Video</p>
                    <p className="mt-1 text-sm text-[#64748B]">an authorized SkyMirr reseller.</p>
                  </div>
                  <a
                    href="https://www.bhphotovideo.com/c/search?q=skymirr"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex shrink-0 items-center justify-center rounded-full border border-[#FF6A00] bg-[#1F4FD8] px-5 py-3 text-sm font-bold text-white"
                  >
                    Shop at B&amp;H →
                  </a>
                </div>
                <div className="mt-4 border-t border-[#E6EAF0] pt-4">
                  <p className="mb-3 text-xs font-bold uppercase tracking-[0.14em] text-[#64748B]">Buy online</p>
                  <div className="flex flex-wrap items-center gap-2">
                    <a
                      href="https://www.amazon.com/s?k=skymirr"
                      target="_blank"
                      rel="noreferrer"
                      aria-label="Search SkyMirr on Amazon"
                      className="s5g-marketplace s5g-marketplace-amazon"
                    >
                      <svg viewBox="0 0 96 34" role="img" aria-label="Amazon" className="h-7 w-[76px]" fill="none">
                        <text x="8" y="22" fontSize="23" fontWeight="700" fill="#172033" fontFamily="Arial, sans-serif">amazon</text>
                        <path d="M20 27 C37 34 61 33 77 25" stroke="#FF9900" strokeWidth="2.8" strokeLinecap="round"/>
                        <path d="M70 24 L78 24 L75 30" stroke="#FF9900" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </a>
                    <a
                      href="https://www.walmart.com/search?q=skymirr"
                      target="_blank"
                      rel="noreferrer"
                      aria-label="Search SkyMirr on Walmart"
                      className="s5g-marketplace s5g-marketplace-walmart"
                    >
                      <svg viewBox="0 0 112 28" role="img" aria-label="Walmart" className="h-6 w-[92px]">
                        <text x="0" y="20" fontSize="19" fontWeight="700" fill="#0071CE" fontFamily="Arial, sans-serif">Walmart</text>
                        <g transform="translate(96 13)" fill="#FFC220">
                          <rect x="-1.5" y="-7" width="3" height="6" rx="1.5"/>
                          <rect x="-1.5" y="1" width="3" height="6" rx="1.5"/>
                          <rect x="-7" y="-1.5" width="6" height="3" rx="1.5"/>
                          <rect x="1" y="-1.5" width="6" height="3" rx="1.5"/>
                          <rect x="-5.7" y="-5.7" width="3" height="6" rx="1.5" transform="rotate(-45 -4.2 -2.7)"/>
                          <rect x="2.7" y="1.7" width="3" height="6" rx="1.5" transform="rotate(-45 4.2 4.7)"/>
                        </g>
                      </svg>
                    </a>
                    <a
                      href="https://www.digikey.com/en/supplier-centers/skymirr"
                      target="_blank"
                      rel="noreferrer"
                      aria-label="Find SkyMirr on DigiKey"
                      className="s5g-marketplace s5g-marketplace-digikey"
                    >
                      <svg viewBox="0 0 96 28" role="img" aria-label="DigiKey" className="h-6 w-[78px]">
                        <text x="0" y="20" fontSize="20" fontWeight="800" fill="#CC0000" fontFamily="Arial, sans-serif">DigiKey</text>
                      </svg>
                    </a>
                    <a
                      href="https://www.bhphotovideo.com/c/search?q=skymirr"
                      target="_blank"
                      rel="noreferrer"
                      aria-label="Search SkyMirr at B&H"
                      className="s5g-marketplace s5g-marketplace-bh"
                    >
                      <svg viewBox="0 0 54 28" role="img" aria-label="B&H Photo Video" className="h-6 w-[48px]">
                        <text x="0" y="21" fontSize="21" fontWeight="900" fill="#D71920" fontFamily="Arial, sans-serif">B&amp;H</text>
                      </svg>
                    </a>
                  </div>
                </div>
                <button type="button" onClick={onContact} className={`${sideBtn} mt-4 !py-3`}>
                  Contact Skymirr For Bulk Purchase (MOQ: 10 Units)
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Product information — same copy, reorganized into a cleaner editorial grid */}
        <div className="mt-10 grid grid-cols-1 gap-5 md:grid-cols-2 lg:mt-14 lg:gap-6">
          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">01 / The problem</p>
            <h2 className={h2}>The Challenge</h2>
            <p className={body}>
              In rugged landscapes and dense urban environments, millions struggle with slow, unstable internet. Weak
              RF signals and limited fiber access create persistent connectivity gaps, restricting education,
              commerce, and everyday life.
            </p>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">02 / The solution</p>
            <h2 className={h2}>The Solution: SkyMirr Sky5G Router</h2>
            <p className={body}>
              Meet the SkyMirr Sky5G Router—engineered for businesses, communities, and users who demand fast,
              resilient, and secure broadband. Fully certified on T-Mobile’s 5G network and T-Priority, Sky5G sets a
              new standard for performance, even in locations where other routers can’t deliver.
            </p>
            <p className={body}>
              Sky5G is a <strong className="text-[#0B1F3A]">CES2026 Innovation Award Honoree</strong>.
            </p>
          </section>

          <section className="s5g-info-card space-y-4 md:col-span-2">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">03 / Product engineering</p>
            <h2 className={h2}>Superior Connectivity By Design</h2>
            <p className={body}>
              Unlike traditional routers where antennas are an afterthought, SkyMirr’s exclusive MuLCAT®
              antenna-first engineering puts signal strength and reliability front and center. Experience up to{" "}
              <strong className="text-[#0B1F3A]">42% farther reach to cell towers</strong>, enhanced indoor coverage,
              and consistently high speeds—even during network congestion or in remote locations.
            </p>
            <div
              role="img"
              aria-label="Illustration of a Sky5G router communicating wirelessly with a cellular base station and connected devices"
              className="s5g-frame w-full overflow-hidden rounded-2xl bg-[#F5F8FF] p-3 sm:p-5"
            >
              <svg viewBox="0 0 900 300" className="block h-auto w-full" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <linearGradient id="sky5gBlue" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#1F4FD8"/>
                    <stop offset="100%" stopColor="#0B1F3A"/>
                  </linearGradient>
                  <linearGradient id="sky5gOrange" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#FF6A00"/>
                    <stop offset="100%" stopColor="#FF9A3C"/>
                  </linearGradient>
                </defs>
                <rect x="1" y="1" width="898" height="298" rx="20" fill="#FFFFFF" stroke="#D8E2F3" strokeWidth="2"/>
                <path d="M70 238 H830" stroke="#D8E2F3" strokeWidth="2" strokeLinecap="round"/>
                {/* Cellular base station */}
                <g transform="translate(115 56)" stroke="#1F4FD8" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" fill="none">
                  <path d="M45 55 L15 185 M45 55 L76 185 M25 140 H65 M31 110 H59 M38 80 H52"/>
                  <path d="M45 55 V20"/>
                  <path d="M27 28 Q45 8 63 28 M17 17 Q45 -10 73 17" stroke="#FF6A00" strokeWidth="4"/>
                  <rect x="34" y="44" width="22" height="26" rx="5" fill="#EAF0FF" stroke="#1F4FD8"/>
                </g>
                <text x="160" y="270" textAnchor="middle" fill="#0B1F3A" fontSize="18" fontWeight="700" fontFamily="Arial, sans-serif">5G Base Station</text>
                {/* Wireless link */}
                <path d="M245 133 C320 67 375 67 448 133" stroke="#1F4FD8" strokeWidth="3" strokeDasharray="8 8" fill="none"/>
                <path d="M248 153 C318 98 377 98 446 153" stroke="#FF6A00" strokeWidth="3" strokeDasharray="5 8" fill="none"/>
                <circle cx="345" cy="104" r="8" fill="#FF6A00"/>
                <circle cx="345" cy="104" r="18" fill="none" stroke="#FF6A00" strokeOpacity=".28" strokeWidth="3"/>
                <text x="345" y="190" textAnchor="middle" fill="#52627A" fontSize="15" fontWeight="600" fontFamily="Arial, sans-serif">Secure wireless link</text>
                {/* Router */}
                <g transform="translate(465 88)">
                  <rect x="0" y="24" width="185" height="112" rx="18" fill="url(#sky5gBlue)"/>
                  <rect x="13" y="36" width="159" height="73" rx="10" fill="#102A54" stroke="#4C78E8" strokeWidth="2"/>
                  <path d="M28 57 H157 M28 68 H157 M28 79 H157" stroke="#4269B9" strokeWidth="2" opacity=".7"/>
                  <path d="M25 24 L8 0 M160 24 L177 0" stroke="#0B1F3A" strokeWidth="7" strokeLinecap="round"/>
                  <circle cx="45" cy="123" r="4" fill="#FF6A00"/>
                  <circle cx="61" cy="123" r="4" fill="#FF6A00"/>
                  <circle cx="77" cy="123" r="4" fill="#FF6A00"/>
                  <rect x="22" y="146" width="140" height="6" rx="3" fill="url(#sky5gOrange)"/>
                </g>
                <text x="557" y="270" textAnchor="middle" fill="#0B1F3A" fontSize="18" fontWeight="700" fontFamily="Arial, sans-serif">Sky5G Router</text>
                {/* Connected devices */}
                <g transform="translate(735 92)" stroke="#1F4FD8" strokeWidth="4" strokeLinejoin="round" fill="none">
                  <rect x="0" y="0" width="66" height="49" rx="6" fill="#EAF0FF"/>
                  <path d="M33 49 V61 M17 62 H49"/>
                  <rect x="18" y="80" width="34" height="61" rx="7" fill="#FFF4EC" stroke="#FF6A00"/>
                  <path d="M29 131 H41" stroke="#FF6A00" strokeWidth="3"/>
                </g>
                <path d="M654 143 C686 125 698 125 727 143" stroke="#1F4FD8" strokeWidth="3" strokeDasharray="6 7" fill="none"/>
                <text x="768" y="270" textAnchor="middle" fill="#0B1F3A" fontSize="18" fontWeight="700" fontFamily="Arial, sans-serif">Connected devices</text>
              </svg>
            </div>
            <ul className={ul}>
              {bullets.map((b) => <li key={b}>{b}</li>)}
            </ul>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">04 / Core technology</p>
            <h2 className={h2}>Superior Connectivity By Design</h2>
            <ul className={ul}>
              <li>
                <strong>MuLCAT® Antenna:</strong> AI-driven, real-time optimization ensures peak performance and
                extends connectivity to challenging areas without upgrading carrier networks.
              </li>
              <li>
                <strong>Wi-Fi 7 Integration:</strong> Delivers seamless, high-speed connections for streaming, remote
                work, and online learning.
              </li>
            </ul>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">05 / Benefits</p>
            <h2 className={h2}>Key Benefits</h2>
            <ul className={ul}>
              <li><strong>2x Coverage Area:</strong> Connect more users and devices across broader spaces.</li>
              <li><strong>50% Power Savings:</strong> Lower energy consumption for cost-effective, sustainable operations.</li>
              <li><strong>Real-Time Optimization:</strong> Automatic adjustments keep your connection strong in tough conditions.</li>
            </ul>
          </section>

          <section className="s5g-info-card space-y-4 md:col-span-2">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">06 / Network compatibility</p>
            <p className={body}>Sky5G is certified for</p>
            <ul className={ul}>
              <li>
                <strong>T-Mobile’s Standard 5G Network</strong>—delivering fast speeds, broad coverage, and
                enterprise-grade reliability.
              </li>
              <li>
                <strong>T-Priority</strong>- where mission-critical users enjoy elevated network access, priority
                queuing during congestion, hardened connections for public safety, and enhanced reliability for first
                responders and emergency services. It is approved for use by: Police, Fire, EMS, emergency operations,
                public works, school districts, utility and infrastructure agencies.
              </li>
              <li>
                <strong>AT&amp;T’s standard 5G network</strong> - delivering reliable 5G connectivity on the AT&amp;T
                network for business, mobile, and connectivity-challenged environments.
              </li>
            </ul>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">07 / Specifications</p>
            <h2 className={h2}>Technical Highlights</h2>
            <ul className={`${ul} s5g-cols`}>
              {technicalHighlights.map((t) => <li key={t}>{t}</li>)}
            </ul>
          </section>

          <section className="s5g-info-card space-y-4">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#FF6A00]">08 / Applications</p>
            <h2 className={h2}>Versatile Use Cases</h2>
            <ul className={ul}>
              {useCases.map(([t, d]) => (
                <li key={t}><strong>{t}:</strong> {d}</li>
              ))}
            </ul>
          </section>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox.isOpen && (
        <div
          onClick={close}
          className="s5g-fade fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-[#0B1F3A]/85 cursor-zoom-out"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="s5g-pop relative bg-white rounded-3xl max-w-6xl w-full max-h-[92vh] overflow-auto p-6 sm:p-8 border border-[#4C8DF6]"
          >
            <div className="flex items-center justify-between pb-4 border-b border-[#E3D4BA]">
              <h3 className="text-sm sm:text-base font-bold text-[#0B1F3A]">{lightbox.title}</h3>
              <button
                onClick={close}
                aria-label="Close"
                className="p-2 rounded-xl text-[#5B6B82] hover:bg-[#E8F0FE] hover:text-[#1F4FD8] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="pt-6 flex justify-center">
              <img src={lightbox.src} alt={lightbox.title} className="max-w-full h-auto object-contain" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};