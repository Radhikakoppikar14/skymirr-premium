import React, { useState } from "react";
import { PageBackdrop } from "../components/fx/PageBackdrop";
import { Calendar, ArrowRight, Sparkles, ChevronRight } from "lucide-react";
import { LiveWaveCanvas } from "../components/fx/LiveWaveCanvas";
import { ModalShell } from "../components/sm/Modalshell";

interface PressItem {
  id: string;
  title: string;
  date: string;
  image: string;
  isLogoThumb?: boolean;
  excerpt: string;
  content: string;
}

interface PressReleasesPageProps {
  onNavigateBlog?: () => void;
}

export const PressReleasesPage: React.FC<PressReleasesPageProps> = ({ onNavigateBlog }) => {
  const [selectedItem, setSelectedItem] = useState<PressItem | null>(null);

  const items: PressItem[] = [
    {
      id: "pr-ces2026",
      title: "SkyMirr To Showcase Breakthrough Wireless Technologies At CES 2026",
      date: "December 29, 2025",
      image: "/images/blogs/skymirr-post-thumb-new.jpg",
      isLogoThumb: true,
      excerpt:
        "MELBOURNE, FL — December 29, 2025— SkyMirr, a leading innovator in antenna-first wireless and IoT connectivity solutions, announced today that it will showcase its latest lineup of high-performance technologies at CES 2026 in Las Vegas.",
      content:
        "MELBOURNE, FL — December 29, 2025 — SkyMirr, a leading innovator in antenna-first wireless and IoT connectivity solutions, announced today that it will showcase its latest lineup of high-performance technologies at CES 2026 in Las Vegas.\n\nAttendees will have the opportunity to see SkyMirr's award-winning Sky5G Router, the SkyBlade™ antenna series, and live spherical anechoic chamber test demonstrations showing how MuLCAT® positive coupling control eliminates blind spots in commercial and industrial IoT deployments.",
    },
    {
      id: "pr-tmobile",
      title: "SkyMirr's Sky5G Router Achieves Certification On T-Mobile's Network And T-Priority",
      date: "December 11, 2025",
      image: "/images/blogs/skymirr-post-thumb-new.jpg",
      isLogoThumb: true,
      excerpt:
        "MELBOURNE, FL — December 11, 2025 SkyMirr, a leader in IOT/wireless innovation, today announced that its advanced 5G wireless router, Sky5G™, has officially achieved certification for use on T-Mobile's network.",
      content:
        "MELBOURNE, FL — December 11, 2025 SkyMirr, a leader in IOT/wireless innovation, today announced that its advanced 5G wireless router, Sky5G™, has officially achieved certification for use on T-Mobile's network and T-Priority mission-critical public safety services.\n\nThis certification guarantees seamless compatibility, priority queuing, and verified low-latency performance for enterprise, rural, and first-responder deployments across North America.",
    },
    {
      id: "pr-ces-honoree",
      title: "SkyMirr's Sky5G™ Wireless Router Named CES 2026 Innovation Awards® Honoree",
      date: "November 6, 2025",
      image: "/images/blogs/skymirr-post-thumb-new.jpg",
      isLogoThumb: true,
      excerpt:
        "MELBOURNE, FL November 6, 2025 SkyMirr, an antenna-first technology company redefining wireless performance through its breakthrough MuLCAT® (Multi-Layer Coupling Controlled Antenna Technology), is honored to announce that its Sky5G™ Wireless Router has been named a CES® 2026 Honoree.",
      content:
        "MELBOURNE, FL — November 6, 2025 SkyMirr, an antenna-first technology company redefining wireless performance through its breakthrough MuLCAT® (Multi-Layer Coupling Controlled Antenna Technology), is honored to announce that its Sky5G™ Wireless Router has been named a CES® 2026 Innovation Awards Honoree.\n\nThe CTA jury commended SkyMirr's internal antenna array which delivers 42% farther reach to cell towers and 2x coverage area compared to typical competitive CPE gateways.",
    },
    {
      id: "pr-mwc",
      title: "SkyMirr Launches Sky5G Router At MWC — Setting A New Standard For 5G Connectivity",
      date: "March 2025",
      image: "/images/blogs/skymirr-post-thumb-new.jpg",
      isLogoThumb: true,
      excerpt:
        "BARCELONA — Mobile World Congress — SkyMirr today launched its flagship Sky5G Router (TCPA 117), setting a new benchmark for 5G fixed wireless broadband and mobile gateway performance.",
      content:
        "BARCELONA — Mobile World Congress — SkyMirr today launched its flagship Sky5G Router (TCPA 117), setting a new benchmark for 5G fixed wireless broadband and mobile gateway performance. Leveraging proprietary MuLCAT® electromagnetic positive coupling control, the router delivers unprecedented signal gain across 600 MHz to 6 GHz without bulky external antenna poles.",
    },
    {
      id: "pr-skyblade",
      title: "SkyMirr Introduces SkyBlade, The World's First True Global 5G Ultra-Wideband Antenna",
      date: "March 2025",
      image: "/images/blogs/skymirr-post-thumb-new.jpg",
      isLogoThumb: true,
      excerpt:
        "MELBOURNE, FL — March 2025 — SkyMirr announced the commercial release of the SkyBlade™ antenna family, including the TAMP161, TAMP154, and TAMP141.",
      content:
        "MELBOURNE, FL — March 2025 — SkyMirr announced the commercial release of the SkyBlade™ antenna family, including the TAMP161, TAMP154, and TAMP141. Designed as a universal drop-in antenna for enterprise cellular gateways and connected vehicles, SkyBlade delivers an industry-first continuous radiation efficiency >80% across the entire 600 MHz to 6000 MHz spectrum.",
    },
    {
      id: "pr-series-a",
      title: "SkyMirr Secures $7.3M Series A Investment Led By Solyco Capital",
      date: "January 2025",
      image: "/images/blogs/skymirr-post-thumb-new.jpg",
      isLogoThumb: true,
      excerpt:
        "MELBOURNE, FL — January 2025 — SkyMirr, Inc. announced the successful closing of a $7.3 Million Series A financing round led by Solyco Capital.",
      content:
        "MELBOURNE, FL — January 2025 — SkyMirr, Inc. announced the successful closing of a $7.3 Million Series A financing round led by Solyco Capital. The funding supports the expansion of SkyMirr's automated manufacturing facilities in Bac Ninh, Vietnam and Incheon, Korea, and accelerates commercial deployments of the Sky5G router and SkyTracker IoT platform with Tier-1 carriers and enterprise partners.",
    },
  ];

  return (
    <div className="pt-20 sm:pt-24 pb-24 bg-[#FFFFFF] text-[#0b1f3a] overflow-x-hidden relative">
      
      {/* Executive Hero Command Deck */}
      <section className="relative isolate overflow-hidden bg-gradient-to-b from-[#0B1F3A] via-[#0B1F3A] to-[#0B1F3A] text-white py-16 sm:py-24">
        <PageBackdrop variant="illustration" />
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden opacity-45">
          <LiveWaveCanvas
            frequency={0.015}
            amplitude={28}
            speed={0.02}
            colorScheme="cyan"
            interactive={true}
            showParticles={true}
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#0B1F3A] border border-[#4C8DF6]/40 text-xs font-mono font-bold tracking-widest uppercase text-[#4C8DF6]">
            <Sparkles className="w-3.5 h-3.5 text-[#4C8DF6] animate-pulse" />
            <span>Official Dispatches</span>
          </div>

          <div className="max-w-3xl space-y-4">
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.08]">
              Press Releases
            </h1>
            <p className="text-base sm:text-lg text-[#C9D6EE] leading-relaxed font-normal">
              Official corporate announcements, carrier certifications, and technological milestones from SkyMirr.
            </p>
          </div>

          {onNavigateBlog && (
            <div className="pt-1">
              <button
                onClick={onNavigateBlog}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#4C8DF6] hover:text-white underline cursor-pointer"
              >
                <span>Explore Technical Blogs</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Press Releases Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {items.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedItem(item)}
            className="bg-white rounded-3xl border border-[#E3D4BA] shadow-xl overflow-hidden hover:border-[#4C8DF6] hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between cursor-pointer group"
          >
            <div>
              <div className="relative aspect-[16/10] bg-[#0B1F3A] p-4 flex items-center justify-center overflow-hidden border-b border-[#E3D4BA]">
                <img
                  src={item.image}
                  alt={item.title}
                  className="max-h-40 w-auto max-w-full object-contain group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div className="p-6 space-y-3">
                <div className="flex items-center gap-2 text-[11px] font-mono text-[#5B6B82]">
                  <Calendar className="w-3.5 h-3.5 text-[#1F4FD8]" />
                  <span>{item.date}</span>
                </div>

                <h3 className="text-base font-bold text-[#0b1f3a] leading-snug group-hover:text-[#1F4FD8] transition-colors">
                  {item.title}
                </h3>

                <p className="text-xs text-[#5B6B82] line-clamp-3 leading-relaxed">
                  {item.excerpt}
                </p>
              </div>
            </div>

            <div className="p-6 pt-0">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#1F4FD8] uppercase font-mono group-hover:translate-x-1 transition-transform">
                <span>Read Full Dispatch</span>
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Modal */}
      {selectedItem && (
        <ModalShell
          onClose={() => setSelectedItem(null)}
          closeLabel="Close Release"
          header={<span className="sm-m-meta text-sm font-mono font-semibold">{selectedItem.date}</span>}
        >
          <h2 className="sm-m-title text-xl sm:text-2xl">{selectedItem.title}</h2>
          <div className="sm-m-media">
            <img src={selectedItem.image} alt={selectedItem.title} />
          </div>
          <div className="sm-m-text">{selectedItem.content}</div>
        </ModalShell>
      )}

    </div>
  );
};